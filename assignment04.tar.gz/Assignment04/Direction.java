package assignment04;
public enum Direction {
		UP, DOWN
	}

