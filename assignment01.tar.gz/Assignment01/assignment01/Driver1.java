package assignment01;
public class Driver1 {
    public static void main(String[] args) {
        BankAccount1 acct = new BankAccount1("Jane Smith", 100.0);
        System.out.println(acct);
    }
}
